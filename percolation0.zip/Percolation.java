

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**----------------------------------------------------------------
*  Author:        Vadim Dupanov
        *  Written:       03/02/2016
        *  Last updated:  09/02/2016
        *
        *  Compilation:   javac src.Percolation.java
        *  Execution:     java src.Percolation
        *This program creates an empty array of booleans
        * with 2 additional elements (virtual start and virtual end)
        *and declares other API methods to
        * open site @method open
        * check if site is open @method isOpen
        *check is site has connection with virtual start (0) @method isFull
        * check if system percolates @method percolates
        *----------------------------------------------------------------*/


public class Percolation {
    private Boolean[] grid;
    private int N;  // size of the NxN area
    private WeightedQuickUnionUF findObject;


    public Percolation(int N) {   // create N-by-N grid, with all sites blocked
        this.N = N;
        if(N<=0){
            throw new IllegalArgumentException("N="+N + " is out of allowed range;" );
        }
        grid = new Boolean[N * N + 2];
        findObject = new WeightedQuickUnionUF(N*N+2);
    }

    public void open(int i, int j) { // open grid (row i, column j) if it is not open already

           if(validate(i, j)) {
               int thisPoint = xyTo1D(i, j);
               grid[thisPoint] = true;

               /*
               * this lines connects virtual 0 and N+1 elements
               * with first and last row respectively
               * */
               if (thisPoint <= N && thisPoint >= 1) findObject.union(0, thisPoint);
               if (thisPoint <= N * N && thisPoint >= N * (N - 1) + 1) findObject.union(N * N + 1, thisPoint);

               //linkin open site with neighbours
               if (i+1<=N && isOpen(i + 1, j) ) {
                   findObject.union(xyTo1D(i + 1, j), thisPoint);
               }
               if (i-1>=1 && isOpen(i - 1, j)) {
                   findObject.union(xyTo1D(i - 1, j), thisPoint);
               }
               if (j+1 <= N && isOpen(i, j + 1)) {
                   findObject.union(xyTo1D(i, j + 1), thisPoint);
               }
               if (j-1>=1 && isOpen(i, j - 1)) {
                   findObject.union(xyTo1D(i, j - 1), thisPoint);
               }
           }
    }

    public boolean isOpen(int i, int j) {// is grid (row i, column j) open?
        if (validate(i, j)) {
            if (grid[xyTo1D(i, j)]) return true;
            return false;
        }
        return false;
    }

    public boolean isFull(int i, int j){// is grid (row i, column j) full?
        if(validate(i, j)) {
            int thisPoint = xyTo1D(i, j);
            return findObject.connected(0, thisPoint);
        }
        return false;
    }

    public boolean percolates(){ // does the system percolate?
        return findObject.connected(0, N*N+1);
    }

    private int xyTo1D(int i, int j){ // turns i row j column into 1D index
        return (i-1)*N + (j-1)+1;
    }

    private boolean validate(int i, int j){
        if (i< 1 || i > N) {
            throw new IndexOutOfBoundsException("index " + i + " is not between 1 and " + N);
        }
        if (j< 1 || j > N) {
            throw new IndexOutOfBoundsException("index " + j + " is not between 1 and " + N);
        }
        return true;
    }

    public static void main(String[] args)  {// UnionCheck client (optional)
        int N = 10;
        Percolation perc = new Percolation(N);
        perc.open(1, 1);
        perc.open(1, 2);
        if(perc.findObject.connected(0,1)) System.out.println("yes");
        }
}