import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.Stopwatch;

/**
 * ----------------------------------------------------------------
 * Author:        Vadim Dupanov
 * Written:       03/02/2016
 * Last updated:  8/7/2006
 * <p>
 * Compilation:   javac PercolationStats.java
 * Execution:     java PercolationStats
 * This program declares an API to gather
 * statistics for Percolation class
 * ----------------------------------------------------------------
 */

public class PercolationStats {
    private double[] results;

    public PercolationStats(int N, int T) { // perform t independent experiments on an n-by-n grid
        if (T <= 0) throw new IllegalArgumentException("T " + T + " is out of bounds");
        if (N <= 0) throw new IllegalArgumentException("N " + N + " is out of bounds");

        results = new double[T];

        for (int i = 0; i < T; i++) {
            int openSites = 0;
            Percolation perc = new Percolation(N);
            while (!perc.percolates()) {
                int row = StdRandom.uniform(1, N + 1); // random value for rows and columns
                int col = StdRandom.uniform(1, N + 1);

                //Checks is random values brings to the new site
                if (!perc.isOpen(row, col)) {
                    perc.open(row, col);
                    openSites++;
                }
            }
            results[i] = (double) openSites / (N * N);
        }

    }

    public double mean() {                      // sample mean of percolation threshold
        return StdStats.mean(results);
    }

    public double stddev() { // sample standard deviation of percolation threshold
        return StdStats.stddev(results);
    }

    public double confidenceLo() { // low  endpoint of 95% confidence interval
        return mean() - (1.96 * stddev() / Math.sqrt(results.length));
    }

    public double confidenceHi() { // high endpoint of 95% confidence interval
        return mean() + (1.96 * stddev() / Math.sqrt(results.length));
    }

    public static void main(String[] args) { // UnionCheck client (described below)
        Stopwatch stpwtch = new Stopwatch();
        PercolationStats test = new PercolationStats(400, 100);
        System.out.println("Elapsed time = " + stpwtch.elapsedTime());
        System.out.println("mean = " + test.mean());
        System.out.println("stddev = " + test.stddev());
        System.out.println("95%  confidence interval = " + test.confidenceLo() + ", " + test.confidenceHi());
    }
}