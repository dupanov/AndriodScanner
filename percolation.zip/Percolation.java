import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * ----------------------------------------------------------------
 * Author:        Vadim Dupanov
 * Written:       03/02/2016
 * Last updated:  8/7/2006
 * <p>
 * Compilation:   javac Percolation.java
 * Execution:     java Percolation
 * This program creates an empty array of booleans
 * with 2 additional elements (virtual start and virtual end)
 * and declares other API methods to
 * open site @method open
 * check if site is open @method isOpen
 * check is site has connection with virtual start (0) @method isFull
 * check if system percolates @method percolates
 * ----------------------------------------------------------------
 */


public class Percolation {
    private boolean[] grid;
    private final int N;  // size of the NxN area
    private WeightedQuickUnionUF findObject;


     public Percolation(int size) {  // create N-by-N grid, with all sites blocked
        validateN(size);
        this.N = size;
        int Nsqr = N * N;
        grid = new boolean[Nsqr + 2]; // creates array where 0 element is virtual and others are linked to findObject
      //  grid[0] = true;
        findObject = new WeightedQuickUnionUF(Nsqr + 2);

    }

    public void open(int i, int j) { // open grid (row i, column j) if it is not open already
        if (!isOpen(i, j)) {
            int thisPoint = xyTo1D(i, j);
            grid[thisPoint] = true;  //opens site

               /*
               * this lines connects first row with virtual 0 element
               * */
            if (i == 1) findObject.union(0, thisPoint);
            //linkin open site with neighbours
            if (i <= N - 1 && isOpen(i + 1, j)) {
                findObject.union(thisPoint, xyTo1D(i + 1, j));
            }
            if (i >= 2 && isOpen(i - 1, j)) {
                findObject.union(thisPoint, xyTo1D(i - 1, j));
            }
            if (j <= N - 1 && isOpen(i, j + 1)) {
                findObject.union(thisPoint, xyTo1D(i, j + 1));
            }
            if (j >= 2 && isOpen(i, j - 1)) {
                findObject.union(thisPoint, xyTo1D(i, j - 1));
            }
            if (i == N ) {
                findObject.union(thisPoint, N*N+1);
            }
        }
    }

    public boolean isOpen(int i, int j) { // is grid (row i, column j) open?
        validate(i, j);
        return grid[xyTo1D(i, j)];

    }

    public boolean isFull(int i, int j) { // is grid (row i, column j) full?
        validate(i, j);
        return findObject.connected(0, xyTo1D(i, j));
    }

    public boolean percolates() { // does the system percolates
        if (findObject.connected(0, N*N + 1))
        return true;
        return false;
    }

    private int xyTo1D(int i, int j) { // turns i row j column into 1D index
        return (i - 1) * N + j;
    }

    private void validate(int i, int j) {
        if (!(i >= 1 && i <= N)) {
            throw new IndexOutOfBoundsException("index i " + i + " is not between 1 and " + N);
        }
        if (!(j >= 1 && j <= N)) {
            throw new IndexOutOfBoundsException("index j " + j + " is not between 1 and " + N);
        }
    }

    private void validateN(int val) {
        if (val <= 0) throw new IllegalArgumentException("Value N " + N + " is less than 1");
    }

    public static void main(String[] args) { // UnionCheck client (optional)
        Percolation perc = new Percolation(10);
        System.out.println(perc.isFull(1,1));
        for(int i=1; i<=10; i++) {
            perc.open(i,1);
            System.out.println("isOpen= " + perc.isOpen(i,1));
            System.out.print(" isFull= " + perc.isFull(i,1));
            System.out.println(" percolates= " + perc.percolates());
        }

    }
}