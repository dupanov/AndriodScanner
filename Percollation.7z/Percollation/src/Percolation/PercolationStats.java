package Percolation;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.Stopwatch;

/**----------------------------------------------------------------
 *  Author:        Vadim Dupanov
 *  Written:       03/02/2016
 *  Last updated:  8/7/2006
 *
 *  Compilation:   javac PercolationStats.java
 *  Execution:     java PercolationStats
 *This program declares an API to gather
 * statistics for Percolation class
 *----------------------------------------------------------------*/

public class PercolationStats {
    double confidenceHi, confidenceLo, stddev, mean;
    private int openSites, T, N;
    private double[] results;

    public PercolationStats(int N, int T){// perform T independent experiments on an N-by-N grid

        this.T = T; // creates instance variables for stats gathering
        this.N = N; //T is times repeating, N is grid size;

        results = new double[T];
        for(int i = 0; i<T; i++){
        openSites = 0;
        Percolation perc = new Percolation(N);
        while(!perc.percolates()) {
            int row = StdRandom.uniform(1, N+1); // random value for rows and columns
            int col = StdRandom.uniform(1, N+1);


            //Checks is random values brings to the new site
            if(!perc.isOpen(row, col)){
                perc.open(row, col);
                openSites++;
            }
        }
            results[i] = (double )openSites/(N*N);
        }
    }
    public double mean(){                      // sample mean of percolation threshold
        mean = StdStats.mean(results);
        return mean;
    }
    public double stddev() {// sample standard deviation of percolation threshold
        stddev = StdStats.stddev(results);
        return stddev;
    }
    public double confidenceLo(){ // low  endpoint of 95% confidence interval
        confidenceLo = mean() - (1.96*stddev/T);
        return confidenceLo;
    }
    public double confidenceHi(){// high endpoint of 95% confidence interval
        confidenceHi = mean() + (1.96*stddev/T);
        return confidenceHi;
    }

    public static void main(String[] args){// UnionCheck client (described below)
        Stopwatch stpwtch = new Stopwatch();
        PercolationStats test = new PercolationStats(200, 100);
        System.out.println("Elapsed time = " + stpwtch.elapsedTime());
        System.out.println("mean = " + test.mean());
        System.out.println("stddev = " +test.stddev());
        System.out.println("95%  confidence interval = " + test.confidenceLo() + ", " + test.confidenceHi());
    }
}