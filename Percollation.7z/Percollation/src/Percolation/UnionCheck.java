package Percolation;

import edu.princeton.cs.algs4.QuickFindUF;

/**
 * Created by Вадик on 09.02.2016.
 */
public class UnionCheck {


    public static void main(String[] args) {
        QuickFindUF qf= new QuickFindUF(10);
        qf.union(9, 3);
        qf.union(6,0);
        qf.union(2,1);
        qf.union(9,0);
        qf.union(8,9);
        qf.union(8,1);

        System.out.println();


    }
}
