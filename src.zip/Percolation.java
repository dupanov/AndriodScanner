import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**----------------------------------------------------------------
*  Author:        Vadim Dupanov
        *  Written:       03/02/2016
        *  Last updated:  8/7/2006
        *
        *  Compilation:   javac Percolation.java
        *  Execution:     java Percolation
        *This program creates an empty array of booleans
        * with 2 additional elements (virtual start and virtual end)
        *and declares other API methods to
        * open site @method open
        * check if site is open @method isOpen
        *check is site has connection with virtual start (0) @method isFull
        * check if system percolates @method percolates
        *----------------------------------------------------------------*/


public class Percolation {
    private boolean[] grid;
    private boolean percolFlag;
    private final int N;  // size of the NxN area
    private WeightedQuickUnionUF findObject;


    public Percolation(int size) {   // create N-by-N grid, with all sites blocked
        validateN(size);
		percolFlag = false;
        this.N = size;
        int Nsqr = N*N;
        grid = new boolean[Nsqr+1]; // creates array where 0 element is virtual and others are linked to findObject
		grid[0] = true;
        findObject = new WeightedQuickUnionUF(Nsqr + 1);

    }

    public void open(int i, int j) { // open grid (row i, column j) if it is not open already
           if (!isOpen(i, j)) {
               int thisPoint = xyTo1D(i, j);
               grid[thisPoint] = true;  //opens site

               /*
               * this lines connects first row with virtual 0 element
               * */
               if (i == 1) findObject.union(thisPoint, 0);
               //linkin open site with neighbours
               if (i <= N-1 && isOpen(i + 1, j)) {
                   findObject.union(xyTo1D(i + 1, j), thisPoint);
                   
                }
               if (i >= 2 && isOpen(i - 1, j)) {
                   findObject.union(xyTo1D(i - 1, j), thisPoint);
                   if (i == N && isFull(i - 1, j)) percolFlag = true;
               }
               if (j <= N-1 && isOpen(i, j + 1)) {
                   findObject.union(xyTo1D(i, j + 1), thisPoint);
                   if (i == N && isFull(i , j + 1)) percolFlag = true;
               }
               if (j >= 2 && isOpen(i, j - 1)) {
                   findObject.union(xyTo1D(i, j - 1), thisPoint);
                   if (i == N && isFull(i, j - 1)) percolFlag = true;
               }
	       if (i == N && isFull(i - 1, j)) percolFlag = true;
              
           }
    }

    public boolean isOpen(int i, int j) { // is grid (row i, column j) open?
        validate(i, j);
        return grid[xyTo1D(i, j)];

    }

    public boolean isFull(int i, int j) { // is grid (row i, column j) full?
        validate(i, j);
        return findObject.connected(0, xyTo1D(i, j));
    }

    public boolean percolates() { // does the system percolates
      return percolFlag;
    }

    private int xyTo1D(int i, int j) { // turns i row j column into 1D index
        return (i-1)*N + (j-1) +1;
    }

    private void validate(int i, int j) {
        if (!(i >= 1 && i <= N)) {
            throw new IndexOutOfBoundsException("index i " + i + " is not between 1 and " + N);
        }
        if (!(j >= 1 && j <= N)) {
            throw new IndexOutOfBoundsException("index j " + j + " is not between 1 and " + N);
        }
    }

    private void validateN(int val) {
        if (val <= 0) throw new IllegalArgumentException("Value N " + N + " is less than 1");
    }

    public static void main(String[] args) { // UnionCheck client (optional)
    }
}